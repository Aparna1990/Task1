const fs = require('fs'),
    config = JSON.parse(fs.readFileSync('config/config.json')).config,
    db = require('./lib/data-access/pgp').db,
    Routes = require('./lib/routes/routes'),
    Hapi = require('Hapi'),
    sqlFilesCache = require('./lib/sql');
class App { 
    constructor() { 
        this.dependencies = {}
        this.config = config;
        this.dependencies.sqlFilesCache = sqlFilesCache;
        this.requestContext = { 'headers': { 'x-ecom-tenant-id': "SEB" } };
        this.routes = new Routes();
        this.dependencies.logger = console;
        this.dependencies.pgpExchangeService = db(this.config.postgres.connection);
    }

    async init() { 
        this.dependencies.logger.log("Init done in App js");
        await this.registerRoutes();  
    }

    async registerRoutes() { 
        let server = await this.startServer();
        this.routes.init(server);
        this.routes.routes(server);
    }

    async startServer()
    {
        const server = new Hapi.Server({
            host: this.config.server.host,
            port: this.config.server.port
        });
      //  (new routes()).initServers();
        
        server.start();
        this.dependencies.logger.log("Server listening at " + server.info.uri);
        return server;
    }

    
}

module.exports=App;
