const fs = require('fs'),
    config = JSON.parse(fs.readFileSync('config/config.json')).config,
    sinon = require('sinon'),
    sqlFilesCache = require('./../lib/sql');

class UnitTestBase { 
    constructor() { 
        this.dependencies = {};
        this.dependencies.sqlFilesCache = sqlFilesCache;
        this.config = config;
        this.requestContext = { 'headers': {'x-com-tenant-id':'SEB'}}
    }

    init() { 
        this.dependencies.logger.log = console;
    }

    createStubbedPromise(instance, method, resolveValue, rejectValue) { 
        return sinon.stub(instance, method).callsFake(() => { 
            return new Promise((resolve, reject) => { 
                if (rejectValue) {
                    reject(rejectValue);
                }
                else
                    resolve(resolveValue);
            })
        })
    }


}
module.exports = UnitTestBase;