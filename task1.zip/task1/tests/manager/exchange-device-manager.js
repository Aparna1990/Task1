const 
    dbHelper = require('../db-helper'),
    assert = require('assert'),
    ExchangeDeviceManager = require('../../lib/manager/exchange-device-manager'),
    ExchangeDeviceDbAccessor = require('../../lib/data-access/exchange-device-db-accessor');

class ExchangeDeviceManagerTest { 
    constructor() { 
        this.init();
        this.exchangeDeviceDbAccessor = new ExchangeDeviceDbAccessor();
        this.exchangeDeviceManager = new ExchangeDeviceManager();
    }
    init() { 
        describe('ExchangeDeviceManager', () => {
            this.executeTests();
        });
    }

    executeTests() { 
        describe('getAllExchangeDevices', () => { 
            afterEach(() => {
             //   dbHelper.deleteTable('exchange_device');
            });
            it('should fetch all the exchange devices', async () => {
                let exchangeDevices = await this.exchangeDeviceDbAccessor.getAll();
                assert.equal(exchangeDevices.length, 1);
            });
        })
    }
}

new ExchangeDeviceManagerTest();