const db = require('../lib/data-access/pgp').db,
    fs = require('fs'),
    config = JSON.parse(fs.readFileSync('config/config.json')).config;

async function deleteTable(tableName) { 
    let deleteCommand = `delete from ${tableName}`;
    
    try { 
        let pgp = db(config.postgres.connection);
        await pgp.none(deleteCommand);
    }
    catch (err) {
        throw err;
    }

}

module.exports = {deleteTable}