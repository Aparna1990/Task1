-- data to load in rabbitmq

rabbitmqadmin declare exchange name='test.notification_service' type=direct durable=true

rabbitmqadmin declare queue name='test.notification_service.email' durable=true
rabbitmqadmin declare binding source='test.notification_service' destination_type=queue destination='test.notification_service.email' routing_key=notifications.email