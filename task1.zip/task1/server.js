const App = require('./app');

(new App()).init(); 